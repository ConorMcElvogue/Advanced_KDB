export REL="2018.05.16"
export VER="3.6"

export QHOME=/home/mcelvogc/q/${VER}/${REL}
export Q=${QHOME}/l64/q

export DATADIR=/home/mcelvogc/adv_kdb

export PORT_TP=5510
export PORT_RDB1=5511
export PORT_RDB2=5512
export PORT_HDB=5513
export PORT_CEP=5611
export PORT_FH=5610

export SCHEMA="sym"
export TPTIMER=100 
