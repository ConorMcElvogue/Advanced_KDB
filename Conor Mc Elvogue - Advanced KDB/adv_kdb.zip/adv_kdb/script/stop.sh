#!/bin/bash

PROJDIR="$( cd "$(dirname "$0")" ; pwd -P )/.."
cd $PROJDIR

include () {
    if [[ ! -f "$1" ]] ; then
        echo "config "$1" not found, exit"
        exit 1
    fi
    source $1
}

include ${PROJDIR}/"config/env.sh"

function KILL_ALL(){
    main tp
    sleep 2
    main fh
    sleep 2
    main rdb1
    sleep 2
    main rdb2
    sleep 2
    main cep
}

function IS_ACTIVE(){
 
    file="$2"
    if [ -f "$file" ] 
	then 
        PID=`cat ${file}`
		if ps -p "$PID" > /dev/null 
 		then 
        	echo "${1} IS ACTIVE"
       		 ps -Fw -p ${PID}
    	else 
       		echo "${1} IS NOT ACTIVE"
		fi
    fi

}


function main(){
	case $1 in
		tp)
			kill `cat ${DATADIR}/logs/pids/tp.pid`
			rm ${DATADIR}/logs/pids/tp.pid
			;;
		fh)
			kill `cat ${DATADIR}/logs/pids/feed.pid`
			rm ${DATADIR}/logs/pids/feed.pid
			;;
		rdb1)
			kill `cat ${DATADIR}/logs/pids/rdb1.pid`
			rm ${DATADIR}/logs/pids/rdb1.pid
			;;
		rdb2)
			kill `cat ${DATADIR}/logs/pids/rdb2.pid`
			rm ${DATADIR}/logs/pids/rdb2.pid
			;;
		cep)
			kill `cat ${DATADIR}/logs/pids/cep.pid`
			rm ${DATADIR}/logs/pids/cep.pid
			;;
    *)
	esac
}

case $1 in
    ALL)
    KILL_ALL
    ;;
    ONE)
    main $2
    ;;
    TEST)
    IS_ACTIVE TP ${DATADIR}/logs/pids/tp.pid
	sleep 1
	IS_ACTIVE FH ${DATADIR}/logs/pids/feed.pid
	sleep 1  
	IS_ACTIVE RDB1 ${DATADIR}/logs/pids/rdb1.pid
	sleep 1
	IS_ACTIVE RDB2 ${DATADIR}/logs/pids/rdb2.pid
	sleep 1 
	IS_ACTIVE CEP  ${DATADIR}/logs/pids/cep.pid
    ;;
  * )
  esac

exit 0
